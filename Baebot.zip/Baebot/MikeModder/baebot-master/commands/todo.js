exports.run = (client, message, args) => {
    return message.channel.send("This is a list of things to be done. \n```1 - Get fights started. \n2 - Driving Simulator.```")
}