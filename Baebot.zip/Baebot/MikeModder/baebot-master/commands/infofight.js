exports.run = (client, message, args) => {
    return message.channel.send("Do +fight @opponent. Characters include: Whiplash (the speedy one), Jager (the strong one), and Medic.");    
}