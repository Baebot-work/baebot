exports.run = (client, message, args) => {
    return message.channel.send("**Cypher123#0589**: The owner of the bot and this server. \n**Bit#8289**: Like, pretty much the co-coder of the bot. He did loads of work. \n**mikemodder007#7678**: The one who made the base of the bot. Also helped with other things. \n**GamersGotPower#9571**: The one who also helped with coding.");    
}