exports.run = (client, message, args) => {
    return message.channel.send("Here is my home server: https://discord.gg/PthAt9e");
}