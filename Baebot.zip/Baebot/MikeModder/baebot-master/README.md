# BAEBot
BAEBot is a WIP Discord bot written in JavaScript using the discord.js library!
