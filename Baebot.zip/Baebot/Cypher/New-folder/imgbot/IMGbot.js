const discord = require("discord.js");
const client = new discord.Client();
const config = require("./config.json");

var prefix = "m";
var token = config.token;
var ownerID = "215232862822072320";

client.on("ready", () =>{
  console.log("InitioMG Bot started and ready!");
  client.user.setGame(`Say ${prefix}help`);
});

client.on("message", message => {
  if (message.author.bot || message.author.id === client.user.id || message.content[0] !== prefix || message.channel.type === "dm") {return;}

  let command = message.content.substring(1).split(" ")[0];
  let params = message.content.substring(1).split(" ").slice(1);

  switch (command) {
   case "help":
   message.channel.send("__COMMANDS__: \n**help** - Shows this! \n**info** - Shows info about the bot.");
   break;

   case "info":
   message.channel.send("This bot is a bot made by Cypher123#0589 for his Discord server (this one), which is a server for his YouTube channel: InitioMG! Here's a link: https://www.youtube.com/channel/UCX17jwzJ-TO3y4YD5PmH1AA")
   break;

   case "die":
   var member = message.author
    member.roles.find("name", "bot test")
     message.channel.send("Shutting down...");
     process.exit(0)
     break;
 }
});

  client.login(token);
