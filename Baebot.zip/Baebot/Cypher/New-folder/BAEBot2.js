//BAEBot
const Discord = require("discord.js");
var client = new Discord.Client();
var youtubedl = require("youtube-dl");

var commandPrefix = "+";
var token = "MzI0MjUyNTkzNTc4ODM1OTY4.DCHEFQ.DGNzmLh8FYF_YNoT0Y3lBERkdL8";
var ownerID = "215232862822072320";

client.on('ready', () =>{
    console.log("BAEBot is ready!")
    client.user.setGame('Say '+commandPrefix+'help for help!');
});

client.on('message', message => {

    if(!message.content.startsWith(commandPrefix) || message.author.bot) return;
    
    if(message.content.startsWith(commandPrefix+"help")){
        message.channel.send("__COMMANDS__\nsay - repeats what you say\ninvite - puts the bots oauth URL in chat\navatar - shows avatar of tagged user, shows authors icon if no users are tagged\nabout - shows some info about the bot\naffiliates - shows some affilitated bots and servers\nytinfo - shows info about the linked yt video\nhelp - shows this\n__ADMIN COMMANDS__\nshutdown - stops bot\nsetgame - sets bots game\nsetflag - sets a flag for the bot\n\n__INFO__\nFound a bug? Report it to mikemodder007#7678!");
    }

    if(message.content.startsWith(commandPrefix+"shutdown")){
        if(message.author.id===ownerID){
            message.channel.send("Stopping BAEBot...");
            client.destroy();
        } else {
            message.channel.send("You don't have permission to run that command!");
        }
    }

    if(message.content.startsWith(commandPrefix+"say")){
        var toSay = message.content.substr('5');
        message.channel.send(":robot: "+toSay);
    }

    if(message.content.startsWith(commandPrefix+'about')){
        message.channel.send('BAEBot -- A WIP Bot by MikeModder007, Cypher123\nBAEBot version 000\nMade using NodeJS and discord.js\n\nBased off 007Bot');
    }

    if(message.content.startsWith(commandPrefix+"invite")){
        message.channel.send("You want BAEBot in your server?\nAlright, here is the OAuh URL:\nNO URL JUST YET");
    }

    if(message.content.startsWith(commandPrefix+"avatar")){
        if(message.mentions.users.size > 0){
            mentionedUser = message.mentions.users.first();
            var avatarURL = mentionedUser.avatarURL;
            message.channel.sendMessage({
                "embed": {
                    title: mentionedUser+"'s' Avatar",
                    url: avatarURL,
                    "image": {
                        "url": avatarURL
                    }
                }
            })
        } else {
            mentionedUser = message.author;
            var avatarURL = mentionedUser.avatarURL;
            message.channel.sendMessage({
                "embed": {
                    title: "Your Avatar",
                    url: avatarURL,
                    "image": {
                        "url": avatarURL
                    }
                }
            })
        }
    }

    if(message.content.startsWith(commandPrefix+"setgame")){
        if(message.author.id===ownerID){
            var newGame = message.content.substr('8');
            client.user.setGame(newGame);
        } else {
            message.channel.send("You don't have permission to run that command!");
        }
    }

    if(message.content.startsWith(commandPrefix+"affiliates")){
        message.channel.send("Here are some affiliated servers/bots!\n\n**Cypher123:**\n__Bots and Elsewhat:__ https://discord.gg/xappyYT");
    }

    if(message.content.startsWith(commandPrefix+"setflag")){
        var args = message.content.split(" ").slice(1);
        var flagName = args[0];
        var flagValue = args[1];
        if(message.author.id===ownerID){
            switch(flagName){
            case "0":
                commandPrefix = flagValue;
                message.channel.send("Changed command prefix to "+flagValue);
                client.user.setGame("Say "+commandPrefix+"help for help!");
                break;
            default:
                message.channel.send("An error has occured! Possible invalid flag or programming issue!");
                break;
        }
        } else {
            message.channel.send("You don't have permission to run that command!");
        }

    }

    if(message.content.startsWith(commandPrefix+"embedimg")){
        var args = message.content.split(" ").slice(1);

        var imageURL = args[0]
        message.channel.sendMessage({
            "embed": {
                title: "Image",
                url: imageURL,
                "image": {
                    "url": imageURL
                }
            }
        })
    }

    if(message.content.startsWith(commandPrefix+"ytinfo")){
        var args = message.content.split(" ").slice(1);

        var videoURL = args[0];
        youtubedl.getInfo(videoURL, function(err, info){
            message.channel.send("Video Title: "+info.title+"\nDescription: "+info.description);
            message.channel.sendMessage({
                "embed": {
                    title: "Thumbnail",
                    url: info.thumbnail,
                    "image": {
                        "url": info.thumbnail
                    }
                }
            });
        });
    }
    if(message.content.startsWith(commandPrefix+"test")){
let items = ["1one","2two","3three"]
let num = Math.floor(Math.random() * items.length);
switch(num){
case 0:
      message.channel.send("Yo");
  return; //always do this at the end
case 1:
        message.channel.send("Hi");
  return;
case 2:
      message.channel.send("'Ello");
  return; //always do this at the end
case 3:
        message.channel.send("Hoi");
  return;
}
   }
});

client.on("error", (e) => console.error(e));
client.on("warn", (e) => console.warn(e));
client.on("debug", (e) => console.info(e));

client.login(token);