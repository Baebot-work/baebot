const discord = require("discord.js");
const client = new discord.Client();

var prefix = "+";
var token = "MzI0MjUyNTkzNTc4ODM1OTY4.DCHEFQ.DGNzmLh8FYF_YNoT0Y3lBERkdL8";
var ownerID = "215232862822072320";

client.on("ready", () =>{
  console.log("BAEBot started and ready!");
  client.user.setGame(`Say ${prefix}help for help!`);
});

client.on("message", message => {
  if (message.author.bot || message.author.id === client.user.id || message.content[0] !== prefix) return;

  let command = message.content.substring(1).split(" ")[0];
  let params = message.content.substring(1).split(" ").slice(1);

  switch (command) {
    case "ping":
      message.channel.send("Pong! -- The bot is alive");
      break;
    case "help":
      message.channel.send("__COMMANDS__\nping - pong!\nhelp - shows this\n\n**If you find any bugs, report them!**");
      break;
    case "gametime":
      if (message.author.id !== ownerID) {
        message.channel.send(`Unverified or you aren\'t the owner. The current owner is <@!${ownerID}>`);
        return;
      }
      var lines = ["@here Game time! Join with +join!", "@here Looks like it\'s game time! Join with +join!"];
      message.channel.send(lines[Math.floor(Math.random() * lines.length)])
      break;
      case "join":
        var role = message.guild.roles.find("name", "game-time-players");
        if (role !== null) { // If it doesn't exist, create a new one.
          role = message.guild.createRole({name: "game-time-players"});
        }
        message.member.addRole(role);
        message.channel.send("Joined!");
        break;
    case "leave":
      var role = message.guild.roles.find("name", "game-time-players");
      message.member.removeRole(role);
      message.channel.send("Left!");
      break;
}
});

client.login(token);
