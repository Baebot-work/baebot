const discord = require("discord.js");
const client = new discord.Client();
const config = require("./config.json");

var prefix = "+";
var token = config.token;
var ownerID = "215232862822072320";

client.on("ready", () =>{
  console.log("BAEBot started and ready!");
  client.user.setGame(`Say ${prefix}help for help!`);
});

client.on("message", message => {
  if(message.channel.name === "updates_and_announcements") {
  message.react("👍");
  message.react("👎");
}
});

client.login(token)
