//BAE Bot
var Discord = require("discord.js");
const client = new Discord.Client();

var commandPrefix = "+";
var token = "MzI0MjUyNTkzNTc4ODM1OTY4.DCHEFQ.DGNzmLh8FYF_YNoT0Y3lBERkdL8";
var ownerID = "215232862822072320";

client.on('ready', () =>{
    console.log('BAEBot started and ready!');
    client.user.setGame("Say "+commandPrefix+"help for help!");
});

client.on('message', message => {
    if(message.author.bot) return;

    if(message.content.startsWith(commandPrefix+"ping")){
        message.channel.send("Pong! -- The bot is alive");
    }
    if(message.content.startsWith(commandPrefix+"help")){
    message.channel.send("__COMMANDS__\nping - pong!\nhelp - shows this\n\n**If you find any bugs, report them!**");
    }
        if(message.content.startsWith(commandPrefix+"game time")){
          if(message.author.id===ownerID){
            if(message.content === commandPrefix+"game time 1"){
            message.channel.send("@here Game time! Join with +join!");
          } else {
            if(message.content === commandPrefix+"game time 2"){
            message.channel.send("@here Looks like it's game time! Join with +join!");
          } else {
            message.channel.send("Unverified or you aren't the owner. If you are, please try again.")
            console.log("Someone tried using game time!");
          }
        }
      }
    }
    if(message.content.startsWith(commandPrefix+"join")){
    let role = message.guild.roles.find("name", "game-time-players");

let member = message.member;

// Add the role!
member.addRole(role).catch(console.error);
}

if(message.content.startsWith(commandPrefix+"leave")){
let role = message.guild.roles.find("name", "game-time-players");

let member = message.member;

// Remove the role!
member.removeRole(role).catch(console.error);
}

if(message.content.startsWith(commandPrefix+"remove")){
            if(message.author.id===ownerID){
let role = message.guild.roles.find("name", "game-time-players");

// Let's pretend you mentioned the user you want to add a role to (!addrole @user Role Name):
let member = message.guild.member(message.mentions.users.first());

// Remove a role!
member.removeRole(role).catch(console.error);
} else {
  message.channel.send("Pleb. You aren't the owner!")
  }
}
})
;
client.login(token);
